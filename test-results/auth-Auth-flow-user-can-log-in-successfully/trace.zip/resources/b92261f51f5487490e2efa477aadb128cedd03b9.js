(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__013esbe._.css","static/chunks/node_modules_0671_gv._.js","static/chunks/app_components_SmoothScroll_tsx_0au2ef1._.js"],
    source: "dynamic"
});
