(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_0d5-zb3._.js","static/chunks/node_modules_next_dist_06gz65m._.js"],
    source: "dynamic"
});
